THIS LICENSE AGREEMENT IS AN AGREEMENT BETWEEN YOU (THE PERSON OR COMPANY WHO IS BEING LICENSED TO USE THE SOFTWARE OR DOCUMENTATION) AND RLTSquare.

1. By purchasing the Software you agree with the content of this Agreement
   and agree to use the Software in compliance with this Agreement.

2. You are a user of this Software and RLTSquare is the owner.

3. You may not sell, resell, sub-license or lease any fragment of the Software or its Documentation to anyone.

4. If you distribute original or changed version of the Software, you must include
   this Agreement without any changes and original version of the Software.

5. We do not and will not bear responsibility for any damages (including any loss of your profit or savings)
   caused to you, your business and your information by use or inability to use this Software.

6. We are not liable for prosecution arising from use of the Software against law or for any illegal use.

7. In case of failure to comply with any condition of this Agreement, your license to use the Software will be revoked.

8. Agreement remains effective without any time limits until it is terminated.

9. RLTSquare reserves the right to change Agreement type for future versions of Software.